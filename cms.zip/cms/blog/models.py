from django.db import models
from django.utils.text import slugify
from account.models import Profile
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField
from django.utils import timezone

# Create your models here.

class Category(models.Model):
    name = models.CharField(max_length=30)
    description = models.TextField()

    def __str__(self):
        return self.name


class Post(models.Model):
    statuses = [("D","Darft"),("P","Published")]

    title = models.CharField(max_length = 250)
    content = RichTextField(blank=True, null=True)
    status = models.CharField(max_length=1,choices=statuses,default="D")
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    image = models.ImageField(upload_to="blog/",blank = True)
    date_posted = models.DateTimeField(default=timezone.now)
    slug = models.SlugField(blank=True)
    author = models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return self.title


    def save(self,*args,**kwargs):
        self.slug = slugify(self.title)
        try:
            super().save(*args,**kwargs)
        except:
            pass

#def view(request):
 #   obj = Post.objects.all()
  #  return HttpResponse

