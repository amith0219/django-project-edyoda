from django.urls import path,include
from blog.views import index2,post_details,contact_us_form_view
from blog.views import PostView,PostCreateView,PostListView,PostDetailView,PostDeleteView,PostUpdateView
from django.contrib.auth import views as auth_views
from account import views as user_views 


#from blog.views import HomeView
urlpatterns = [
    path('',PostListView.as_view(),name = "home"),
    path('category/<int:id>',index2,name = "category"),
    path('blogs/<int:pk>',PostDetailView.as_view(),name ="post-detail"),
    path('contact',contact_us_form_view,name ="contact-us"),
    #path('register',register_form_view),
    path('post',PostCreateView.as_view(),name ="post"),
    # path('author/<int:pk>',profile,name ="profile"),
    path('blogs/<int:pk>/delete',PostDeleteView.as_view(),name="post-delete"),
    path('blogs/<int:pk>/update',PostUpdateView.as_view(),name="update"),
    path("",include("django.contrib.auth.urls")),
    path('password-reset/',
         auth_views.PasswordResetView.as_view(
             template_name='registration/password_reset.html'
         ),
         name='password_reset'),
    path('password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='registration/password_reset_done.html'
         ),
         name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='registration/password_reset_confirm.html'
         ),
         name='password_reset_confirm'),
    path('password-reset-complete/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='registration/password_reset_complete.html'
         ),
         name='password_reset_complete'),


]